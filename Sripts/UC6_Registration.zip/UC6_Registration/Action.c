
Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("1P_JAR=2023-01-15-14; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=ARSKqsINhtREkp7HHoWvf5Vss04oH2DhJvUlVgzKcn3AQD9lbkE4zPHOFg; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=js9_USgRIS9_d5n7txyM6lNQ32lmP_JBa_t52HNcrFw0iwH475YKF02hy__rXwt8b98XYyNXR5D8lTh6EtM6TiA306YIi19iTQeg2m4bmqjPEemb0OiybkUyUu5MTd6zPh8T9DDjrZNSYsJBo_5_22VNk0oOPrCRSfHCOrA7v4Q; DOMAIN=accounts.google.com");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Not_A Brand\";v=\"99\", \"Google Chrome\";v=\"109\", \"Chromium\";v=\"109\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("01_sign_up_now");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(48);

	web_url("login.pl", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/home.html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(86);

	web_submit_data("login.pl_2", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={parUserName}", ENDITEM, 
		"Name=password", "Value={parUserPassword}", ENDITEM, 
		"Name=passwordConfirm", "Value={parUserPassword}", ENDITEM, 
		"Name=firstName", "Value={parFirstName}", ENDITEM, 
		"Name=lastName", "Value={parLastName}", ENDITEM, 
		"Name=address1", "Value={parAddres1}", ENDITEM, 
		"Name=address2", "Value={parAddres2}", ENDITEM, 
		"Name=register.x", "Value=62", ENDITEM, 
		"Name=register.y", "Value=8", ENDITEM, 
		LAST);
	
	
	lr_get_transaction_status("01_sign_up_now");

	lr_end_transaction("01_sign_up_now",LR_AUTO);

	return 0;
}